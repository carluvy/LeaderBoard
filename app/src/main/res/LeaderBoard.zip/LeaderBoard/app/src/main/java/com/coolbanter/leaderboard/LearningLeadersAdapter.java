package com.coolbanter.leaderboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LearningLeadersAdapter extends RecyclerView.Adapter<LearningLeadersAdapter.
        LearningLeadersViewHolder>{

    Context mContext;

//    public LearningLeadersAdapter(Context context) {
//        mContext = context;
//
//    }

    @NonNull
    @Override
    public LearningLeadersAdapter.LearningLeadersViewHolder onCreateViewHolder
            (@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.learning_leaders_item_list, parent, false);
        return new LearningLeadersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LearningLeadersAdapter.LearningLeadersViewHolder holder,
                                 int position) {

    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public class LearningLeadersViewHolder extends RecyclerView.ViewHolder {


        public LearningLeadersViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}


