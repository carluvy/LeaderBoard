package com.coolbanter.leaderboard;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

@Entity(tableName = "leader_board_data")

public final class LeaderBoard {

    @PrimaryKey(autoGenerate = true)

    @ColumnInfo(name = "name")
}
