package com.coolbanter.leaderboard;

public class LeaderBoardDao {


}

